class Formation{
  int duree ;
  String nom;
  int? id;
  Formation(this.duree, this.nom , [this.id] );
}